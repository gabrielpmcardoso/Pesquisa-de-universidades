import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SearchScreen({ navigation }) {
  const [country, setCountry] = useState('');
  const [name, setName] = useState('');
  const [results, setResults] = useState([]);

  const search = async () => {
    if (!country && !name) return;

    let url = 'http://universities.hipolabs.com/search?';
    if (country) url += `country=${country}&`;
    if (name) url += `name=${name}`;

    const res = await fetch(url);
    const data = await res.json();
    setResults(data);
  };

  const saveFavorite = async (item) => {
    const stored = await AsyncStorage.getItem('favorites');
    const favorites = stored ? JSON.parse(stored) : [];

    favorites.push({ name: item.name, site: item.web_pages[0] });
    await AsyncStorage.setItem('favorites', JSON.stringify(favorites));
    navigation.navigate('Favoritos');
  };

  return (
    <View style={{ padding: 16 }}>
      <TextInput placeholder="País" value={country} onChangeText={setCountry} />
      <TextInput placeholder="Universidade" value={name} onChangeText={setName} />
      <Button title="Pesquisar" onPress={search} />

      <FlatList
        data={results}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => saveFavorite(item)}>
            <Text>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
