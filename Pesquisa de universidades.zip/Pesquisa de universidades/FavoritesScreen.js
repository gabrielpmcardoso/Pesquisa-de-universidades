import React, { useEffect, useState } from 'react';
import { View, FlatList, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function FavoritesScreen() {
  const [favorites, setFavorites] = useState([]);

  const loadFavorites = async () => {
    const stored = await AsyncStorage.getItem('favorites');
    setFavorites(stored ? JSON.parse(stored) : []);
  };

  useEffect(() => {
    loadFavorites();
  }, []);

  const removeFavorite = async (index) => {
    const updated = favorites.filter((_, i) => i !== index);
    setFavorites(updated);
    await AsyncStorage.setItem('favorites', JSON.stringify(updated));
  };

  return (
    <View style={{ padding: 16 }}>
      <FlatList
        data={favorites}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <TouchableOpacity onPress={() => removeFavorite(index)}>
            <Text>{item.site}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}